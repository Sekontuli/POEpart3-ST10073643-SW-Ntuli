/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import static org.junit.Assert.*;
import org.junit.Test;

/**
 *
 * @author Admin
 */
public class TaskManagerTest {

    TaskManager taskManager = new TaskManager();

    @Test
    public void testDeveloperArrayPopulation() {
        assertEquals("Mike Smith", taskManager.developers.get(0));
        assertEquals("Edward Harrison", taskManager.developers.get(1));
        assertEquals("Samantha Paulson", taskManager.developers.get(2));
        assertEquals("Glenda Oberholzer", taskManager.developers.get(3));
    }

    @Test
    public void testDisplayLongestTask() {
        taskManager.longestDuration();  // Outputs to console; inspect manually or refactor for assertion
    }

    @Test
    public void testSearchTaskByName() {
        taskManager.searchTask("Create Login");
    }

    @Test
    public void testSearchTasksByDeveloper() {
        taskManager.tasksByDeveloper("Samantha Paulson");
    }

    @Test
    public void testDeleteTask() {
        taskManager.deleteTask("Create Reports");
        assertFalse(taskManager.taskNames.contains("Create Reports"));
    }

    @Test
    public void testDisplayReport() {
        taskManager.displayReport();  // Outputs to console; inspect manually or refactor for assertion
    }
}

